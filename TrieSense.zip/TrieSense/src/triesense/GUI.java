package triesense;

import javax.swing.*;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.util.List;

public class GUI {

    private AutoComplete autoComplete;

    public GUI() {
        autoComplete = new AutoComplete();
        autoComplete.loadWords("resources/words.txt");
        createUI();
    }

    private void createUI() {
        JFrame frame = new JFrame("TrieSense - AutoComplete");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        JTextField inputField = new JTextField();
        DefaultListModel<String> listModel = new DefaultListModel<>();
        JList<String> suggestionList = new JList<>(listModel);

        inputField.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { updateSuggestions(); }
            public void removeUpdate(DocumentEvent e) { updateSuggestions(); }
            public void changedUpdate(DocumentEvent e) {}

            private void updateSuggestions() {
                String text = inputField.getText().toLowerCase();
                listModel.clear();
                if (!text.isEmpty()) {
                    List<String> suggestions = autoComplete.getTrie().getSuggestions(text);
                    for (String suggestion : suggestions) {
                        listModel.addElement(suggestion);
                    }
                }
            }
        });

        frame.setLayout(new BorderLayout());
        frame.add(inputField, BorderLayout.NORTH);
        frame.add(new JScrollPane(suggestionList), BorderLayout.CENTER);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
    	 javax.swing.SwingUtilities.invokeLater(GUI::new);
    }
}
