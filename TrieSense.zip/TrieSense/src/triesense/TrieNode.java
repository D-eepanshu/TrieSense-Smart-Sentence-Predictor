package triesense;

import java.util.HashMap;
import java.util.Map;

/**
 * Represents a node within the Trie (prefix tree) data structure.
 * Each node can have multiple child nodes, each representing a subsequent character,
 * and a flag to indicate if the path to this node forms a complete word.
 */
public class TrieNode {
    /**
     * A map where the keys are characters and the values are the child TrieNodes.
     * This allows for efficient traversal to the next character in a word or prefix.
     */
    Map<Character, TrieNode> children;

    /**
     * A boolean flag that is set to `true` if the path from the root to this node
     * represents a complete word that was inserted into the Trie.
     */
    boolean isEndOfWord;

    /**
     * Initializes a new TrieNode. By default, it has an empty map of children,
     * indicating that no subsequent characters have been added yet, and it is
     * not marked as the end of a word.
     */
    public TrieNode() {
        this.children = new HashMap<>();
        this.isEndOfWord = false;
    }

    /**
     * Returns the map of children nodes for this TrieNode.
     *
     * @return The map of child nodes.
     */
    public Map<Character, TrieNode> getChildren() {
        return children;
    }

    /**
     * Checks if this TrieNode marks the end of a valid word.
     *
     * @return `true` if this node represents the end of a word, `false` otherwise.
     */
    public boolean isEndOfWord() {
        return isEndOfWord;
    }

    /**
     * Sets the `isEndOfWord` flag for this TrieNode. This is typically called
     * after inserting the last character of a word into the Trie.
     *
     * @param endOfWord The boolean value to set for the end-of-word flag.
     */
    public void setEndOfWord(boolean endOfWord) {
        this.isEndOfWord = endOfWord;
    }

    /**
     * Adds a child node for a given character to this TrieNode. If a child
     * for the character already exists, it will be overwritten.
     *
     * @param character The character of the child node.
     * @param childNode The child TrieNode to add.
     */
    public void addChild(char character, TrieNode childNode) {
        this.children.put(character, childNode);
    }

    /**
     * Retrieves the child node associated with a given character.
     *
     * @param character The character of the child node to retrieve.
     * @return The child TrieNode for the given character, or `null` if no such child exists.
     */
    public TrieNode getChild(char character) {
        return this.children.get(character);
    }

    /**
     * Checks if this TrieNode has a child node for a given character.
     *
     * @param character The character to check for.
     * @return `true` if a child node exists for the character, `false` otherwise.
     */
    public boolean hasChild(char character) {
        return this.children.containsKey(character);
    }
}