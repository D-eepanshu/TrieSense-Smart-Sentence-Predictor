package triesense;

import java.util.*;

/**
 * Represents a Trie (prefix tree) data structure for efficient string prefix searching
 * and auto-completion/suggestion generation.
 */
public class Trie {
    /**
     * The root node of the Trie. It doesn't represent any character.
     */
    private final TrieNode root;

    /**
     * Initializes an empty Trie with a new root node.
     */
    public Trie() {
        root = new TrieNode();
    }

    /**
     * Inserts a word into the Trie. Each character of the word becomes a node
     * in the Trie, and shared prefixes result in shared nodes. The last node
     * of the word is marked as the end of a word.
     *
     * @param word The word to be inserted into the Trie.
     * @throws IllegalArgumentException if the word is null or empty.
     */
    public void insert(String word) {
        if (word == null || word.isEmpty()) {
            throw new IllegalArgumentException("Word cannot be null or empty.");
        }

        TrieNode node = root;
        // Iterate through each character of the word.
        for (char ch : word.toCharArray()) {
            // Use putIfAbsent to create a new TrieNode only if a child for the
            // current character doesn't already exist.
            node.children.putIfAbsent(ch, new TrieNode());
            // Move to the child node corresponding to the current character.
            node = node.children.get(ch);
        }
        // Mark the last node as the end of a valid word.
        node.isEndOfWord = true;
    }

    /**
     * Retrieves a list of up to 10 words from the Trie that start with the given prefix.
     * The search starts from the root and traverses down the Trie based on the prefix.
     * If the prefix doesn't exist, an empty list is returned.
     *
     * @param prefix The prefix to search for.
     * @return A list of at most 10 words starting with the given prefix.
     * Returns an empty list if no words with the prefix are found.
     * @throws IllegalArgumentException if the prefix is null.
     */
    public List<String> getSuggestions(String prefix) {
        if (prefix == null) {
            throw new IllegalArgumentException("Prefix cannot be null.");
        }

        List<String> results = new ArrayList<>();
        TrieNode node = root;

        // Traverse the Trie based on the characters of the prefix.
        for (char ch : prefix.toCharArray()) {
            if (!node.children.containsKey(ch)) {
                // If any character in the prefix is not found, no suggestions exist.
                return results;
            }
            node = node.children.get(ch);
        }

        // Perform Depth-First Search (DFS) starting from the node representing the end of the prefix
        // to find all words that have this prefix.
        dfs(node, prefix, results);
        return results;
    }

    /**
     * Performs a Depth-First Search (DFS) traversal starting from the given node
     * to find all complete words in the subtree. It appends the characters along the
     * path to the current word to form complete suggestions. The search stops when
     * 10 suggestions are found.
     *
     * @param node    The current node being visited in the DFS.
     * @param word    The current word being built (formed by the path from the root).
     * @param results The list to store the found suggestions.
     */
    private void dfs(TrieNode node, String word, List<String> results) {
        // Optimization: Stop the search if we have already found the maximum number of suggestions.
        if (results.size() >= 10) {
            return;
        }

        // If the current node marks the end of a word, add it to the results.
        if (node.isEndOfWord) {
            results.add(word);
        }

        // Explore the children of the current node.
        for (Map.Entry<Character, TrieNode> entry : node.children.entrySet()) {
            // Recursively call dfs for each child, extending the current word with the child's character.
            dfs(entry.getValue(), word + entry.getKey(), results);
        }
    }

    /**
     * Represents a node in the Trie. Each node can have multiple children (representing
     * the next possible characters) and a flag indicating if this node marks the end of a valid word.
     */
    private static class TrieNode {
        /**
         * A map of children nodes, where the key is the character and the value is the child TrieNode.
         */
        Map<Character, TrieNode> children;

        /**
         * A boolean flag indicating if this node represents the end of a complete word.
         */
        boolean isEndOfWord;

        /**
         * Initializes a new TrieNode with an empty map of children and the end-of-word flag set to false.
         */
        public TrieNode() {
            children = new HashMap<>();
            isEndOfWord = false;
        }
    }
}